<div class="row">
    @foreach($tags as $tag)
        @include('seo::forms.tag')
    @endforeach
</div>