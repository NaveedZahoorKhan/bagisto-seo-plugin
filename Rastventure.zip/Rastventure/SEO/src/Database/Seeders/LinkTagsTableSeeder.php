<?php

namespace Rastventure\SEO\Database\Seeders;

use Illuminate\Database\Seeder;

class LinkTagsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    }
}
